# Input of Coffee Shop Order
sCustomerName = input("Enter Customer Name: ")
sOrderDate = input("Enter Order Date: ")

#Input of Quantity you want
print("Enter Quantity of Coffee: ")
iCoffee = int(input())
print("Enter Quantity of Cookies: ")
iCookie = int(input())
print("Enter Quantity of Muffins: ")
iMuffin = int(input())


# Process (Cost) of Each Item!
dCoffeeCost = float(iCoffee * 2.50)
dCookieCost = float(iCookie * .50 )
dMuffinCost= float(iMuffin * .75)
dTotal= float(dCoffeeCost + dCookieCost + dMuffinCost)
dTax = float(dTotal * 0.06)

#Output of Order(Receipt)
print("Customer Order for " + sCustomerName + " Date: " + sOrderDate)
print("Items Purchased...")
print("Coffees:", iCoffee, " Cookies: ", iCookie, " Muffins: ", iMuffin)
print("Customer Subtotal: $", dTotal)
print("Customer Tax: $", dTax)
print("Amount Due: $", dTax + dTotal)

print("Thank you for business and enjoy your day :) ")
