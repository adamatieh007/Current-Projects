#set counters for car makes and cars in general

iNoOfCarsSold = 0
iFord = 0
iGM = 0
iChrysler = 0
dTotalCarP = 0

#Opened disk file!

inFile = open("CarsSold.dat", "r")

#Printed the opening message and format

print("\t\t\t\t\tCar Sales Report")
sLine = "{0:<20}{1:<16}{2:<15}{3:<10}" .format('Car Make', 'Year', 'Amount Sold', 'Commissions')
print(sLine)

#Made the for...loop structure!

for iLoop in range(1,13):

    #Assigned variables to disk files

    iYear = int(inFile.readline())
    sCarMake = inFile.readline().strip("\n")
    dAmountSold = float(inFile.readline())

    iNoOfCarsSold = iNoOfCarsSold + 1

    #Commission amount for the amount sold!

    dCommissionAmount = 0.01
    if (iYear == 2005) or (iYear == 2006):
        dCommissionAmount = 0.02
    elif (iYear == 2007) or (iYear == 2008):
        dCommissionAmount = 0.03
    elif iYear >= 2009:
        dCommissionAmount = 0.05

    #formula for commission rate

    dCommissionRate = dAmountSold * dCommissionAmount

    #output for the disk file info

    sLine2 = "{0:<20}{1:<10}    {2:9.2f}     {3:10.2f}".format(sCarMake, iYear, dAmountSold, dCommissionRate)
    print(sLine2)

    #Counting the Car Makes

    if sCarMake == "Ford":
        iFord = iFord + 1

    if sCarMake == "GM":
        iGM = iGM + 1

    if sCarMake == "Chrysler":
        iChrysler = iChrysler + 1

    #The car make percentages

    dFordP = iFord/12
    dGMP = iGM/12
    dChryslerP = iChrysler/12

    dTotalCarP = dFordP + dGMP + dChryslerP

#Final output message!

print("Number of Cars Sold: ", iNoOfCarsSold)
print("Percentage of Ford, GM, and Chrysler cars sold: %", dTotalCarP)
