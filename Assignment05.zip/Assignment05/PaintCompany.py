# The counters and accumulators set to 0
iTotalProjNo = 0
iTotalProjHrs = 0
iTotalPainters = 0
iTotalProjCost = 0
# Questions that aren't included in the loop!
sDate = str(input("Enter the date on which the painting projects will be completed (mm/dd/yyyy): "))
iProjNumber = int(input("Enter the Project Number: "))

# The while loop structure!
while iProjNumber > 0:
    iTotalProjNo = iTotalProjNo + 1
    iProjHours = int(input("Enter the total number of hours to complete the painting project:"))
    iTotalProjHrs = iTotalProjHrs + iProjHours
    iPainterNo = int(input("Enter the number of painters needed to complete the project: "))
    iTotalPainters = iTotalPainters + iPainterNo
    dSupplyCost = float(input("Enter the cost of paint supplies needed for the job:"))
    iProjNumber = int(input("Enter the Project Number: "))
    dProjCost = (iProjHours * (iPainterNo * 22.5) + dSupplyCost)
    iTotalProjCost = iTotalProjCost + dProjCost

# The final output of totals
print("Date: ", sDate)
print("The number of painting projects is: ", iTotalProjNo)
print("The total project hours for that day are: ", iTotalProjHrs)
print("The total number of painters needed for the day are: ", iTotalPainters)
print("Project cost for all jobs is: $", iTotalProjCost)
