#opening the disk file.
outFile = open("StudentSurvey.dat", "w")

#main while loop to go with the rest of the loops
while 7 == 7:
    #Name while loop
    while True:
        sHighSchoolName = input("Enter high school name (it cannot be blank): ")
        if sHighSchoolName == "":
            print("High school name cannot be blank. Try again. ")
        else:
            break
    #Grade level while loop
    while True:
        iGradeLvl = int(input("Enter your grade level (9-12th grade): "))
        if (iGradeLvl < 9) or (iGradeLvl > 12):
            print("Must be a grade level between 9 and 12. Try again.")
        else:
            break
    #Tv hours while loop
    while True:
        iAvgTV = int(input("Enter the average number of hours of TV you watch per week: "))
        if iAvgTV < 0:
            print("Number has to be greater than or equal to zero. Try again.")
        else:
            break
    #Phone hours while loop
    while True:
        iAvgPhone = int(input("Enter the average number of hours of time on a phone you use per week: "))
        if iAvgPhone < 0:
            print("Number has to be greater than or equal to zero. Try again.")
        else:
            break
#optional favorite subject input
    sFavoriteSubject = input("Enter your favorite subject (optional): ")
    if sFavoriteSubject == "":
        sFavoriteSubject = "none"
    #final output
    sOutput = sHighSchoolName + "," + str(iGradeLvl) + "," + str(iAvgTV) + "," + str(iAvgPhone) + "," + sFavoriteSubject + "\n"
    outFile.write(sOutput)
    #follow-up question
    sAnotherStudent = input("Would you like to enter another student (Y for Yes and N for No): ")
    if sAnotherStudent == "N":
        outFile.write("dummy")
        break

#closing the disc file!
outFile.close()