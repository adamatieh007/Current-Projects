#importing the random function
import random
#accumulator set to 0
iAccumulate = 0
#array set
iChest = [0,0, 0, 0, 0, 0, 0, 0, 0, 0, 0,]

#for loop for the chests
for iIndex in range(1,11):
    iChest[iIndex] = random.randint(1,100)
iValue = random.randint(1,10)
iChest[iValue] = -1

#while loop for input
while True:

    iChoice = int(input("Enter a chest number between 1 and 10 to get a value: "))

    #if you get a good chest, this is the result
    if iChest[iChoice] > 0:
        iAccumulate = iAccumulate + iChest[iChoice]
        print("You have opened a chest with $", iChest[iChoice], "dollars!")
        iChest[iChoice] = 0
    #once you have opened all good chests, you win!
    elif sum(iChest) == -1:
        print("You have opened all treasure chest boxes with money, your total winnings are $", iAccumulate, "dollars. The game is over!")
        break
    #if you pick the bad chest, game over!
    elif iChest[iChoice] == -1:
        print("Uh oh. You chose the bad chest! GAME OVER!")
        break
    #if you opened a box already, you will be informed
    elif iChest[iChoice] == 0:
        print("You have already opened this box. Try again.")
