# Global Variable arrays!
iTotalSales = [0,0,0,0]
dTotalCommission = [0.0, 0.0, 0.0, 0.0]

# initialization part
def initialization():
    print("*" * 44)
print("*" * 44)
print("\t\t\t\tUltra Tech")
print("*" * 44)
# process sales part with all inputs
def process_sales():
    global iTotalSales, dTotalCommission
# while loop for sales name!
while True:
    sSalesName = input("Enter Sales Name (it cannot be blank): ")
    if sSalesName == "":
        print("Sales name cannot be blank. Try again.")
    else:
        break
# sentinel value loop!
while sSalesName != "end":
    # department number loop
    while True:
        try:
            iDeptNo = int(input("Enter your department number (1 to 3):"))
        except:
            print("Department", iDeptNo, "is invalid.", end='')
        else:
            if iDeptNo < 1 or iDeptNo > 3:
                print("Department", iDeptNo, "is invalid.", end='')
            else:
                break
    # sales amount loop
    while True:
        dSalesAmount = float(input("Enter year-end sales (0 to 10,000): "))
        if dSalesAmount < 0 or dSalesAmount > 10000:
            print("Year end sales is invalid. Try Again ")
        else:
            break

    # formulas and accumulators
    dCommRate = dSalesAmount * 0.02
    iTotalSales[iDeptNo] = iTotalSales[iDeptNo] + dSalesAmount
    dTotalCommission[iDeptNo] = dTotalCommission[iDeptNo] + dCommRate

    # while loop for sales name again
    while True:
        sSalesName = input("Enter Sales Name (it cannot be blank): ")
        if sSalesName == "":
            print("Sales name cannot be blank. Try again.")
        else:
            break

# very long output display summary!
def display_summary():
    print("*" * 5, "Department Totals", "*" * 5)
    print("Department 1 year-end sales: ", iTotalSales[1])
    print("Department 1 year-end commissions paid: ", dTotalCommission[1])
    print("Department 2 year-end sales: ", iTotalSales[2])
    print("Department 2 year-end commissions paid: ", dTotalCommission[2])
    print("Department 3 year-end sales: ", iTotalSales[3])
    print("Department 3 year-end commissions paid: ", dTotalCommission[3])

# calling for all the parts
def main():
    initialization()
    display_summary()
    process_sales()

# entry point!
main()